import * as React from 'react';
import { View,TouchableOpacity,Text,StyleSheet,Image } from 'react-native';
import HoroscopeScreen from './Horoscope';
import JokeScreen from './Jokes';
import WeatherScreen from './Weather';
import TopNewsScreen from './TopNews';

import AppHeader from '../components/AppHeader' 

export default class HomeScreen extends React.Component {
  render() {
    return (
      <View>
       <AppHeader/>
      <TouchableOpacity style={styles.button} onPress={()=>this.props.navigation.navigate('JokeScreen')}>
      <Text>Jokes</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={()=>this.props.navigation.navigate('HoroscopeScreen')}>
      <Text>Horoscope</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={()=>this.props.navigation.navigate('WeatherScreen')}>
      <Text>Weather</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={()=>this.props.navigation.navigate('TopNewsScreen')}>
      <Text>Top News</Text>
      </TouchableOpacity>
      <Text style={{alignSelf:'center',marginTop:65}}>Rate Us</Text>
      
      </View>
    );
  }
}

const styles=StyleSheet.create({
  button:{
    backgroundColor:'violet',
    margin:20,
    padding:10,
    borderColor:'black',
    borderRadius:25,
    width:150,
    alignSelf:'center',
    alignItems:'center'
  }
})