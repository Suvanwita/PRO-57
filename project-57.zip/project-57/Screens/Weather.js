import * as React from 'react';
import { View,TouchableOpacity,Text,StyleSheet,a } from 'react-native';

import AppHeader from '../components/AppHeader'

export default class WeatherScreen extends React.Component {
  render() {
    return (
      <View>
       <AppHeader/>
       <View style={{margin:15}}>
       <Text> WEATHER </Text>
       <Text>
       The easterly moisture-laden winds continue to bring widespread rain accompanied with thunderstorms over South India. In particular, rainfall in excess of 50 mm is likely in some areas of Tamil Nadu on Tuesday. The precipitation accumulation will gradually ease from Wednesday onwards.

A cyclonic circulation is likely to trigger moderate snow or rain accompanied with thundershower over Northeast India. The system could stagnate there for a while.

Scattered snow or rain is expected in alpine areas of Northern India as the western disturbance is approaching Trans Himalayas on Wednesday. In particular, snow totals up to 20 cm in the next two days are likely at isolated places of Ladakh.

Maximum temperature is predicted to be below average in some areas of North and Central India due to an upper-level cold trough lying in North India for the next five days.

Minimum temperature is expected to be warmer than normal for much of India in this period. Whereas, cooler trends are expected in some areas of North and Central India for the next few days.

Shallow to moderate morning fog is expected in some areas of Assam and adjoining region for a while. Dense fog is possible at isolated places of East Rajasthan and Maharashtra on Tuesday morning.
       </Text>
       <a href="https://weather.com/en-IN/india/news/news/2020-11-17-heavy-rainfall-expected-over-isolated-places-of-tamil-nadu">
       Click for more details
       </a>
       </View>
      </View>
    );
  }
}

